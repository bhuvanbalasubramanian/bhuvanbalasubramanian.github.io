
# Mapping rules

1. \*/Site.\* = makes a parameter or telemetry attached to a site
